﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A3RashpalSinghP2
{
    class Program
    {
        static void Main(string[] args)
        {
            int operation = 0;
            double result = 0;

            {
                Console.WriteLine("Type a number :");
                string stringc = Console.ReadLine();
                double r = Convert.ToDouble(stringc);

                Console.WriteLine("Type another number :");
                string stringb = Console.ReadLine();
                double s = Convert.ToDouble(stringb);

                Console.WriteLine("Enter the operation + (addition), - (substraction), * (multiplication), / (division), ^ (exposant) or % (reste) :");
                string stringOperation = Console.ReadLine();

                if (stringOperation == "+" || stringOperation == "addition")
                {
                    operation = 1;
                }
                else if (stringOperation == "-" || stringOperation == "sudstraction")
                {
                    operation = 2;
                }
                else if (stringOperation == "*" || stringOperation == "multiplication")
                {
                    operation = 3;
                }
                else if (stringOperation == "/" || stringOperation == "division")
                {
                    operation = 4;
                }
                else if (stringOperation == "^" || stringOperation == "exposant")
                {
                    operation = 5;
                }
                else if (stringOperation == "%" || stringOperation == "reste")
                {
                    operation = 6;
                }

                switch (operation)
                {
                    case 1:
                        result = r + s;
                        break;

                    case 2:
                        result = r - s;
                        break;

                    case 3:
                        result = r * s;
                        break;

                    case 4:
                        result = r / s;
                        break;

                    case 5:
                        result = Math.Pow(r, s);
                        break;

                    case 6:
                        result = r % s;
                        break;
                }
                Console.WriteLine("Result of " + r + " " + stringOperation + " " + s + " = " + result + ".");
                Console.ReadKey();
            }
        }
    }
}
